"""
Tilde IA API - Tilde IA
Generado por Tilde Manager v6
Fecha: 2026-01-22T12:55:22.573892
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
import requests
import os
import threading
import time
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()


@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({"status": "healthy"})

if __name__ == '__main__':
    port = int(os.getenv('PORT', CONFIG['port']))
    debug = os.getenv('DEBUG', 'True').lower() == 'true'
    
    print(f"🚀 Tilde IA API - {CONFIG['project_name']}")
    print(f"📡 Corriendo en puerto: {port}")
    print(f"🔥 Firewall Inteligente Activo")
    
    app.run(host='0.0.0.0', port=port, debug=debug)
